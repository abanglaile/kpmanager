
const config = {
  //server_url = "http://39.108.85.119:3000";
  server_url: "http://127.0.0.1:3000",
}
//配置常用参数
export default config; 