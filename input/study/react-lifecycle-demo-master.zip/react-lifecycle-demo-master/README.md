# react-lifecycle-demo
测试React组件间生命周期转换   
可参考博客：[React多组件生命周期转换关系](http://www.cnblogs.com/hhhyaaon/p/5807310.html)
